﻿
using ApiLocadora.Models;
using Microsoft.EntityFrameworkCore;

namespace ApiLocadora.DbContext
{
    public class AppDbContext : Microsoft.EntityFrameworkCore.DbContext
    {

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { 
        
        }
        public DbSet<Filme> filmes {  get; set; }
        public DbSet<Estudio> estudios { get; set; }
        public DbSet<Genero> generos { get; set; }

    }
}
