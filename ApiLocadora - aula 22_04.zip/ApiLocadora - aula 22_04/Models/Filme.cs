﻿using Microsoft.AspNetCore.Mvc.Formatters;
using System.ComponentModel.DataAnnotations.Schema;

namespace ApiLocadora.Models
{
    public class Filme
    {
        [Column("id")]
        public int id { get; set;}
        [Column("Diretor")]
        public string Diretor { get; set; }
        [Column("Titulo")]
        public string Titulo { get; set; }

        [Column("Genero")]
        public string Genero { get; set; }
        //public Genero genero { get; set; }
        //public Estudio estudio { get; set; }
        
        [Column("AnoLancamento")]
        public int? AnoLancamento { get; set; }


    }
}
